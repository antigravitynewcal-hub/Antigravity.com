import { useEffect, useState } from "react";

type IconName =
  | "arrow"
  | "bag"
  | "check"
  | "chevron"
  | "close"
  | "menu"
  | "message"
  | "nfc"
  | "shield"
  | "spark"
  | "truck";

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    arrow: (
      <>
        <path d="M5 12h14" />
        <path d="m13 6 6 6-6 6" />
      </>
    ),
    bag: (
      <>
        <path d="M6 8h12l1 12H5L6 8Z" />
        <path d="M9 10V6a3 3 0 0 1 6 0v4" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
    chevron: <path d="m9 18 6-6-6-6" />,
    close: (
      <>
        <path d="m6 6 12 12" />
        <path d="M18 6 6 18" />
      </>
    ),
    menu: (
      <>
        <path d="M4 7h16" />
        <path d="M4 12h16" />
        <path d="M4 17h16" />
      </>
    ),
    message: (
      <>
        <path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z" />
        <path d="M8 10h.01M12 10h.01M16 10h.01" />
      </>
    ),
    nfc: (
      <>
        <path d="M6 8a6 6 0 0 1 0 8" />
        <path d="M3 5a10 10 0 0 1 0 14" />
        <path d="M10 10a3 3 0 0 1 0 4" />
        <circle cx="14" cy="12" r="1" />
      </>
    ),
    shield: (
      <>
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" />
        <path d="m9 12 2 2 4-4" />
      </>
    ),
    spark: <path d="m12 3-1.7 5.3L5 10l5.3 1.7L12 17l1.7-5.3L19 10l-5.3-1.7L12 3Z" />,
    truck: (
      <>
        <path d="M3 6h11v10H3z" />
        <path d="M14 10h4l3 3v3h-7z" />
        <circle cx="7" cy="18" r="2" />
        <circle cx="18" cy="18" r="2" />
      </>
    ),
  };
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  );
}

const products = [
  {
    name: "Tag Comptoir",
    type: "1 point de vente",
    price: "3 990 F",
    color: "coral",
    desc: "Le format essentiel à poser près de votre caisse.",
  },
  {
    name: "Duo Boutique",
    type: "2 tags NFC",
    price: "6 990 F",
    color: "blue",
    desc: "Équipez votre comptoir et votre espace d’accueil.",
  },
  {
    name: "Pack Multi",
    type: "5 tags NFC",
    price: "14 990 F",
    color: "lime",
    desc: "Idéal pour plusieurs caisses ou plusieurs boutiques.",
  },
];

const faqs = [
  [
    "Est-ce compatible avec tous les téléphones ?",
    "Oui, nos tags fonctionnent avec la grande majorité des smartphones récents Android et iPhone, sans application à installer.",
  ],
  [
    "Où est-ce que le tag redirige mes clients ?",
    "Directement sur la fenêtre permettant de laisser un avis sur votre fiche Google. Nous programmons votre lien avant la livraison.",
  ],
  [
    "Livrez-vous partout en Nouvelle-Calédonie ?",
    "Oui. Nous livrons sur le Grand Nouméa et dans toute la Nouvelle-Calédonie. Le délai est précisé lors de la commande.",
  ],
];

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [cartCount, setCartCount] = useState(0);
  const [cartOpen, setCartOpen] = useState(false);
  const [contactOpen, setContactOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [added, setAdded] = useState<string | null>(null);

  useEffect(() => {
    if (!added) return;
    const timeout = window.setTimeout(() => setAdded(null), 1800);
    return () => window.clearTimeout(timeout);
  }, [added]);

  useEffect(() => {
    if (!contactOpen) return;

    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setContactOpen(false);
    };

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", closeOnEscape);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", closeOnEscape);
    };
  }, [contactOpen]);

  const addToCart = (name: string) => {
    setCartCount((count) => count + 1);
    setAdded(name);
  };

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setMenuOpen(false);
  };

  const sendContactEmail = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const subject = `Équipement comptoir — ${form.get("business") || "nouvelle demande"}`;
    const body = [
      `Nom : ${form.get("name")}`,
      `Commerce : ${form.get("business")}`,
      `E-mail : ${form.get("email")}`,
      `Téléphone : ${form.get("phone") || "Non renseigné"}`,
      `Besoin : ${form.get("need")}`,
      "",
      "Message :",
      form.get("message") || "Je souhaite équiper mon comptoir.",
    ].join("\n");

    window.location.href = `mailto:antigravity.newcal@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  return (
    <main className="min-h-screen overflow-hidden bg-[#07110f] text-[#f4f0e8]">
      <header className="fixed inset-x-0 top-0 z-50 border-b border-white/10 bg-[#07110f]/80 backdrop-blur-xl">
        <div className="mx-auto flex h-[74px] max-w-[1240px] items-center justify-between px-5 lg:px-8">
          <button
            className="flex items-center gap-3"
            onClick={() => scrollTo("accueil")}
            aria-label="Retour à l'accueil"
          >
            <span className="logo-mark">A</span>
            <span className="font-display text-[18px] font-bold tracking-[-.03em]">
              ANTIGRAVITY
            </span>
          </button>

          <nav
            className="hidden items-center gap-8 text-sm text-white/70 md:flex"
            aria-label="Navigation principale"
          >
            <button onClick={() => scrollTo("produits")} className="nav-link">
              Produits
            </button>
            <button onClick={() => scrollTo("fonctionnement")} className="nav-link">
              Comment ça marche
            </button>
            <button onClick={() => scrollTo("pro")} className="nav-link">
              Pour les boutiques
            </button>
            <button onClick={() => scrollTo("faq")} className="nav-link">
              FAQ
            </button>
          </nav>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCartOpen(true)}
              className="relative grid h-11 w-11 place-items-center rounded-full border border-white/15 transition hover:bg-white/10"
              aria-label={`Panier, ${cartCount} article${cartCount > 1 ? "s" : ""}`}
            >
              <Icon name="bag" size={19} />
              {cartCount > 0 && (
                <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-[#ff6b4a] px-1 text-[10px] font-bold text-[#07110f]">
                  {cartCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="grid h-11 w-11 place-items-center rounded-full border border-white/15 md:hidden"
              aria-label="Ouvrir le menu"
            >
              <Icon name={menuOpen ? "close" : "menu"} />
            </button>
          </div>
        </div>
        {menuOpen && (
          <nav className="border-t border-white/10 bg-[#07110f] px-5 py-6 md:hidden">
            {["produits", "fonctionnement", "pro", "faq"].map((item) => (
              <button
                key={item}
                onClick={() => scrollTo(item)}
                className="block w-full border-b border-white/10 py-4 text-left capitalize"
              >
                {item === "pro" ? "Pour les boutiques" : item}
              </button>
            ))}
          </nav>
        )}
      </header>

      <section id="accueil" className="relative min-h-[850px] pt-[74px]">
        <div className="absolute inset-0">
          <img
            src="/antigravity-nfc-hero.png"
            alt="Tag NFC Antigravity posé sur le comptoir d'une boutique"
            className="h-full w-full object-cover object-[68%_center]"
          />
          <div className="absolute inset-0 bg-[linear-gradient(90deg,#07110f_0%,rgba(7,17,15,.88)_37%,rgba(7,17,15,.18)_72%,rgba(7,17,15,.55)_100%)]" />
          <div className="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-[#07110f] to-transparent" />
        </div>
        <div className="relative mx-auto flex min-h-[776px] max-w-[1240px] items-center px-5 py-20 lg:px-8">
          <div className="max-w-[690px]">
            <div className="mb-7 inline-flex items-center gap-2 rounded-full border border-[#ff6b4a]/40 bg-[#ff6b4a]/10 px-4 py-2 text-xs font-semibold uppercase tracking-[.18em] text-[#ff8a70]">
              <span className="h-1.5 w-1.5 rounded-full bg-[#ff6b4a] shadow-[0_0_14px_#ff6b4a]" />
              Avis Google · Sans application
            </div>
            <h1 className="font-display text-[clamp(3.5rem,7.7vw,7rem)] font-semibold leading-[.88] tracking-[-.065em]">
              Plus d’avis.
              <br />
              <span className="text-[#ff6b4a]">Plus de confiance.</span>
            </h1>
            <p className="mt-8 max-w-[560px] text-lg leading-relaxed text-white/66 md:text-xl">
              Posez le tag sur votre comptoir. Votre client approche son téléphone et accède
              instantanément à votre page d’avis Google.
            </p>
            <div className="mt-10 flex flex-col gap-3 sm:flex-row">
              <button onClick={() => setContactOpen(true)} className="btn-primary group">
                Équiper mon comptoir <Icon name="arrow" size={19} />
              </button>
              <button onClick={() => scrollTo("fonctionnement")} className="btn-secondary">
                Voir comment ça marche
              </button>
            </div>
            <div className="mt-12 flex flex-wrap gap-x-8 gap-y-3 text-sm text-white/55">
              <span className="flex items-center gap-2">
                <Icon name="check" size={17} /> Compatible iPhone & Android
              </span>
              <span className="flex items-center gap-2">
                <Icon name="check" size={17} /> Lien Google configuré pour vous
              </span>
            </div>
          </div>
        </div>
        <div className="absolute bottom-14 right-6 hidden rounded-2xl border border-white/15 bg-[#07110f]/65 p-4 backdrop-blur-lg lg:block lg:right-10">
          <div className="flex items-center gap-3">
            <span className="pulse-ring">
              <Icon name="nfc" size={22} />
            </span>
            <div>
              <div className="text-xs text-white/50">Approchez votre téléphone</div>
              <div className="text-sm font-semibold">Laissez un avis Google</div>
            </div>
          </div>
        </div>
      </section>

      <section className="border-y border-white/10 bg-[#0b1714]">
        <div className="mx-auto grid max-w-[1240px] grid-cols-2 divide-x divide-white/10 px-5 lg:grid-cols-4 lg:px-8">
          {[
            ["01", "Accès direct aux avis Google"],
            ["02", "Prêt à poser sur le comptoir"],
            ["03", "Livré en Nouvelle-Calédonie"],
            ["04", "Support local"],
          ].map(([num, label]) => (
            <div
              key={num}
              className="flex items-center gap-4 border-b border-white/10 px-3 py-7 even:border-b-0 lg:border-b-0 lg:px-8"
            >
              <span className="font-display text-xs text-[#ff6b4a]">{num}</span>
              <span className="text-sm font-medium">{label}</span>
            </div>
          ))}
        </div>
      </section>

      <section id="produits" className="section-shell py-28">
        <div className="mb-12 flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div>
            <p className="eyebrow">Nos offres comptoir</p>
            <h2 className="section-title">
              Vos clients satisfaits.
              <br />
              Vos meilleurs ambassadeurs.
            </h2>
          </div>
          <p className="max-w-md text-base leading-relaxed text-white/55">
            Chaque tag est configuré avec le lien d’avis Google de votre établissement et livré prêt
            à être posé près de votre caisse.
          </p>
        </div>
        <div className="grid gap-5 md:grid-cols-3">
          {products.map((product, index) => (
            <article key={product.name} className="product-card group">
              <div className={`product-visual product-${product.color}`}>
                <span className="absolute left-5 top-5 rounded-full border border-black/10 bg-white/70 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[.12em] text-[#07110f]">
                  {index === 0 ? "L’essentiel" : index === 1 ? "Le plus choisi" : "Multi-sites"}
                </span>
                {index === 0 && (
                  <div className="tag-shape">
                    <Icon name="nfc" size={42} />
                    <small>VOTRE AVIS</small>
                  </div>
                )}
                {index === 1 && (
                  <div className="card-shape">
                    <div>
                      <Icon name="nfc" size={34} />
                      <b>VOTRE AVIS COMPTE</b>
                      <small>Approchez votre téléphone</small>
                    </div>
                    <div className="review-stars">★★★★★</div>
                  </div>
                )}
                {index === 2 && (
                  <div className="stand-shape">
                    <div className="stand-face">
                      <Icon name="nfc" size={42} />
                      <b>VOTRE AVIS</b>
                      <small>Scannez pour noter</small>
                    </div>
                  </div>
                )}
              </div>
              <div className="p-6">
                <div className="mb-2 flex items-start justify-between gap-4">
                  <div>
                    <p className="text-xs uppercase tracking-[.14em] text-white/40">
                      {product.type}
                    </p>
                    <h3 className="font-display mt-1 text-2xl font-semibold">{product.name}</h3>
                  </div>
                  <span className="whitespace-nowrap font-display text-lg">{product.price}</span>
                </div>
                <p className="mb-6 text-sm text-white/50">{product.desc}</p>
                <button
                  onClick={() => addToCart(product.name)}
                  className="flex w-full items-center justify-between rounded-xl border border-white/15 px-4 py-3.5 text-sm font-semibold transition hover:border-[#ff6b4a] hover:bg-[#ff6b4a] hover:text-[#07110f]"
                >
                  {added === product.name ? "Ajouté au panier" : "Ajouter au panier"}{" "}
                  <Icon name={added === product.name ? "check" : "arrow"} size={17} />
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section id="fonctionnement" className="bg-[#efe9dd] py-28 text-[#07110f]">
        <div className="section-shell">
          <div className="mb-16 max-w-2xl">
            <p className="eyebrow !text-[#df5638]">Simple par nature</p>
            <h2 className="section-title !text-[#07110f]">
              Trois étapes.
              <br />
              Zéro friction.
            </h2>
          </div>
          <div className="grid gap-px overflow-hidden rounded-3xl border border-black/10 bg-black/10 md:grid-cols-3">
            {[
              ["01", "Commandez", "Choisissez le nombre de tags adapté à votre boutique."],
              [
                "02",
                "Nous configurons",
                "Vous nous transmettez votre fiche Google, nous programmons le lien.",
              ],
              [
                "03",
                "Collectez",
                "Posez le tag sur le comptoir. Vos clients laissent leur avis en quelques secondes.",
              ],
            ].map(([num, title, desc]) => (
              <div key={num} className="bg-[#f7f2e9] p-8 lg:p-10">
                <span className="font-display text-sm font-bold text-[#df5638]">{num}</span>
                <div className="my-9 grid h-16 w-16 place-items-center rounded-full bg-[#07110f] text-[#ff6b4a]">
                  <Icon name={num === "01" ? "spark" : num === "02" ? "shield" : "nfc"} size={28} />
                </div>
                <h3 className="font-display text-2xl font-semibold">{title}</h3>
                <p className="mt-3 leading-relaxed text-black/55">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="pro" className="section-shell py-28">
        <div className="relative overflow-hidden rounded-[32px] border border-white/10 bg-[#0d201c] px-6 py-14 md:px-14 lg:px-20 lg:py-20">
          <div className="orb orb-one" />
          <div className="orb orb-two" />
          <div className="relative grid items-center gap-14 lg:grid-cols-[1.15fr_.85fr]">
            <div>
              <p className="eyebrow">Solutions professionnelles</p>
              <h2 className="font-display text-[clamp(2.8rem,5vw,5rem)] font-semibold leading-[.95] tracking-[-.05em]">
                Transformez chaque passage
                <br />
                en avis Google.
              </h2>
              <p className="mt-6 max-w-xl text-lg leading-relaxed text-white/58">
                Restaurants, hôtels, salons, commerces ou cabinets : facilitez le bon geste au
                meilleur moment, juste après une expérience réussie.
              </p>
              <button
                onClick={() =>
                  (window.location.href =
                    "mailto:bonjour@antigravity.nc?subject=Demande%20professionnelle")
                }
                className="btn-primary mt-9"
              >
                Parler de mon projet <Icon name="arrow" size={19} />
              </button>
            </div>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
              {[
                ["Accès en un geste", "Aucune recherche de votre établissement"],
                ["Sans application", "Compatible avec les smartphones récents"],
                ["Prêt à l’emploi", "Votre lien Google est déjà configuré"],
              ].map(([title, desc]) => (
                <div
                  key={title}
                  className="flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[.045] p-5 backdrop-blur"
                >
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-[#ff6b4a]/15 text-[#ff7c5e]">
                    <Icon name="check" />
                  </span>
                  <div>
                    <h3 className="font-semibold">{title}</h3>
                    <p className="mt-1 text-sm text-white/45">{desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="faq" className="section-shell pb-28">
        <div className="grid gap-12 lg:grid-cols-[.75fr_1.25fr]">
          <div>
            <p className="eyebrow">Questions fréquentes</p>
            <h2 className="section-title">
              Besoin d’un
              <br />
              signal ?
            </h2>
            <p className="mt-5 text-white/50">Notre équipe locale vous répond rapidement.</p>
          </div>
          <div className="border-t border-white/15">
            {faqs.map(([question, answer], index) => (
              <div key={question} className="border-b border-white/15">
                <button
                  onClick={() => setOpenFaq(openFaq === index ? null : index)}
                  className="flex w-full items-center justify-between gap-5 py-6 text-left font-display text-lg font-semibold"
                >
                  {question}
                  <span className={`transition-transform ${openFaq === index ? "rotate-90" : ""}`}>
                    <Icon name="chevron" />
                  </span>
                </button>
                <div
                  className={`grid transition-all duration-300 ${openFaq === index ? "grid-rows-[1fr] pb-6" : "grid-rows-[0fr]"}`}
                >
                  <p className="overflow-hidden pr-10 leading-relaxed text-white/52">{answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t border-white/10 bg-[#050c0a]">
        <div className="section-shell py-14">
          <div className="flex flex-col justify-between gap-12 md:flex-row">
            <div>
              <div className="flex items-center gap-3">
                <span className="logo-mark">A</span>
                <span className="font-display text-lg font-bold">ANTIGRAVITY</span>
              </div>
              <p className="mt-4 max-w-xs text-sm leading-relaxed text-white/40">
                Le tag NFC qui transforme vos clients satisfaits en avis Google.
                <br />
                Pensée en Nouvelle-Calédonie.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-12 text-sm sm:grid-cols-3">
              <div>
                <p className="mb-4 font-semibold">Explorer</p>
                <button onClick={() => scrollTo("produits")} className="footer-link">
                  Produits
                </button>
                <button onClick={() => scrollTo("fonctionnement")} className="footer-link">
                  Comment ça marche
                </button>
              </div>
              <div>
                <p className="mb-4 font-semibold">Entreprise</p>
                <button onClick={() => scrollTo("pro")} className="footer-link">
                  Solutions pro
                </button>
                <a href="mailto:bonjour@antigravity.nc" className="footer-link">
                  Contact
                </a>
              </div>
              <div className="col-span-2 sm:col-span-1">
                <p className="mb-4 font-semibold">Nous contacter</p>
                <a href="mailto:bonjour@antigravity.nc" className="footer-link">
                  bonjour@antigravity.nc
                </a>
                <span className="footer-link">Nouméa, NC</span>
              </div>
            </div>
          </div>
          <div className="mt-14 flex flex-col justify-between gap-3 border-t border-white/10 pt-6 text-xs text-white/30 sm:flex-row">
            <span>© 2025 Antigravity. Tous droits réservés.</span>
            <span>Propulsé depuis le Pacifique.</span>
          </div>
        </div>
      </footer>

      <button
        onClick={() => (window.location.href = "mailto:bonjour@antigravity.nc")}
        className="fixed bottom-5 right-5 z-40 grid h-14 w-14 place-items-center rounded-full bg-[#ff6b4a] text-[#07110f] shadow-[0_10px_35px_rgba(255,107,74,.3)] transition hover:scale-105"
        aria-label="Nous contacter"
      >
        <Icon name="message" />
      </button>

      {contactOpen && (
        <div
          className="fixed inset-0 z-[70] overflow-y-auto bg-[#030806]/85 p-4 backdrop-blur-md sm:p-6"
          role="dialog"
          aria-modal="true"
          aria-labelledby="contact-title"
          onClick={() => setContactOpen(false)}
        >
          <div className="flex min-h-full items-center justify-center">
            <section
              className="relative w-full max-w-3xl overflow-hidden rounded-[28px] border border-white/12 bg-[#0b1714] shadow-2xl"
              onClick={(event) => event.stopPropagation()}
            >
              <div className="absolute right-0 top-0 h-56 w-56 rounded-full bg-[#ff6b4a]/12 blur-3xl" />
              <div className="relative grid md:grid-cols-[.82fr_1.18fr]">
                <div className="border-b border-white/10 bg-[#0e211d] p-7 md:border-b-0 md:border-r md:p-9">
                  <p className="eyebrow">Votre projet</p>
                  <h2
                    id="contact-title"
                    className="font-display mt-4 text-4xl font-semibold leading-[.95] tracking-[-.045em]"
                  >
                    Équipons votre comptoir.
                  </h2>
                  <p className="mt-5 text-sm leading-relaxed text-white/55">
                    Parlez-nous de votre commerce. Votre application e-mail s’ouvrira avec votre
                    demande déjà rédigée.
                  </p>
                  <div className="mt-8 flex items-center gap-3 text-sm text-white/70">
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-[#ff6b4a]/15 text-[#ff7859]">
                      <Icon name="message" size={18} />
                    </span>
                    <span className="break-all">antigravity.newcal@gmail.com</span>
                  </div>
                </div>

                <form className="relative p-7 md:p-9" onSubmit={sendContactEmail}>
                  <button
                    type="button"
                    onClick={() => setContactOpen(false)}
                    className="absolute right-5 top-5 grid h-10 w-10 place-items-center rounded-full border border-white/15 text-white/70 transition hover:bg-white/10 hover:text-white"
                    aria-label="Fermer le formulaire"
                  >
                    <Icon name="close" size={18} />
                  </button>

                  <div className="grid gap-5 pt-10 sm:grid-cols-2 md:pt-8">
                    <label className="contact-field">
                      <span>Votre nom</span>
                      <input name="name" type="text" placeholder="Prénom et nom" required />
                    </label>
                    <label className="contact-field">
                      <span>Votre commerce</span>
                      <input
                        name="business"
                        type="text"
                        placeholder="Nom de l’établissement"
                        required
                      />
                    </label>
                    <label className="contact-field">
                      <span>Votre e-mail</span>
                      <input name="email" type="email" placeholder="vous@commerce.nc" required />
                    </label>
                    <label className="contact-field">
                      <span>Téléphone</span>
                      <input name="phone" type="tel" placeholder="+687 ..." />
                    </label>
                    <label className="contact-field sm:col-span-2">
                      <span>Votre besoin</span>
                      <select name="need" defaultValue="Un comptoir">
                        <option>Un comptoir</option>
                        <option>Plusieurs comptoirs</option>
                        <option>Plusieurs établissements</option>
                        <option>Je souhaite être conseillé</option>
                      </select>
                    </label>
                    <label className="contact-field sm:col-span-2">
                      <span>Votre message</span>
                      <textarea
                        name="message"
                        rows={4}
                        placeholder="Précisez votre besoin, votre ville ou le nombre de points de vente…"
                      />
                    </label>
                  </div>

                  <button type="submit" className="btn-primary mt-6 w-full">
                    Préparer mon e-mail <Icon name="arrow" size={19} />
                  </button>
                  <p className="mt-3 text-center text-xs leading-relaxed text-white/35">
                    L’envoi final se fait depuis votre application e-mail.
                  </p>
                </form>
              </div>
            </section>
          </div>
        </div>
      )}

      <div
        className={`fixed inset-0 z-[60] transition ${cartOpen ? "pointer-events-auto bg-black/60" : "pointer-events-none bg-transparent"}`}
        onClick={() => setCartOpen(false)}
      >
        <aside
          className={`absolute right-0 top-0 flex h-full w-full max-w-md flex-col bg-[#0b1714] p-6 shadow-2xl transition-transform duration-300 ${cartOpen ? "translate-x-0" : "translate-x-full"}`}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between border-b border-white/10 pb-5">
            <h2 className="font-display text-2xl font-semibold">Votre panier</h2>
            <button
              onClick={() => setCartOpen(false)}
              className="grid h-10 w-10 place-items-center rounded-full border border-white/15"
            >
              <Icon name="close" />
            </button>
          </div>
          <div className="grid flex-1 place-items-center text-center">
            <div>
              <div className="mx-auto mb-5 grid h-16 w-16 place-items-center rounded-full bg-white/5 text-white/50">
                <Icon name="bag" size={28} />
              </div>
              <p className="font-display text-xl">
                {cartCount
                  ? `${cartCount} article${cartCount > 1 ? "s" : ""} ajouté${cartCount > 1 ? "s" : ""}`
                  : "Votre panier est vide"}
              </p>
              <p className="mt-2 text-sm text-white/45">
                {cartCount ? "Votre sélection est prête." : "Découvrez nos objets connectés."}
              </p>
            </div>
          </div>
          {cartCount > 0 && (
            <button
              onClick={() =>
                (window.location.href =
                  "mailto:commande@antigravity.nc?subject=Ma%20commande%20Antigravity")
              }
              className="btn-primary w-full justify-center"
            >
              Finaliser ma demande <Icon name="arrow" size={19} />
            </button>
          )}
        </aside>
      </div>
    </main>
  );
}
